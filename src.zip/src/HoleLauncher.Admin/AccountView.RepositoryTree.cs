using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Input;
using HoleLauncherBackend.Contracts;

namespace HoleLauncher.Admin;

public sealed partial class AccountView
{
    private string? selectedTreeFile;
    private sealed record RepositoryTreeFile(RepositoryFile File, bool Automatic)
    {
        public string Key => File.ProjectId ?? $"{File.StorageDomain}/{File.StorageId}";
    }

    private void OnRepositoryTreeToggled(object? sender, RoutedEventArgs e)
    {
        if (RepositoryTreePanel is null)
            return;
        RepositoryBuildFilesTab.IsSelected = true;
        var tree = RepositoryTreeToggle.IsChecked == true;
        RepositoryTreePanel.IsVisible = tree;
        RepositoryFiles.IsVisible = !tree;
        RenderRepositoryFiles();
    }

    private void OnRepositoryTreeFolderChanged(object? sender, TextChangedEventArgs e)
    {
        if (RepositoryTreeToggle?.IsChecked == true)
            RenderRepositoryFiles();
    }

    private void RenderRepositoryTree(IEnumerable<RepositoryTreeFile> files)
    {
        var root = new List<TreeViewItem>();
        var folders = new Dictionary<string, TreeViewItem>(StringComparer.OrdinalIgnoreCase);
        foreach (var folder in Value(RepositoryFolders).Split(['\r', '\n'],
            StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries))
            GetFolder(folder);

        TreeViewItem? selected = null;
        foreach (var item in files.OrderBy(item => item.File.Card.Title, StringComparer.CurrentCultureIgnoreCase))
        {
            var file = item.File;
            var folder = file.Folder.Length == 0 && file.ProjectId is not null ? "mods" : file.Folder;
            var leaf = new TreeViewItem { Header = CreateCard(file.Card, compact: true), Tag = item };
            leaf.AddHandler(PointerPressedEvent, (_, args) =>
            {
                if (args.GetCurrentPoint(leaf).Properties.IsLeftButtonPressed && selectedTreeFile == item.Key)
                {
                    RepositoryFileTree.SelectedItem = null;
                    args.Handled = true;
                }
            }, RoutingStrategies.Tunnel);
            if (folder.Length == 0)
                root.Add(leaf);
            else
                GetFolder(folder).Items.Add(leaf);
            if (item.Key == selectedTreeFile)
                selected = leaf;
        }

        RepositoryFileTree.ItemsSource = root;
        RepositoryFileTree.SelectedItem = selected;
        ShowTreeFile(selected?.Tag as RepositoryTreeFile);

        TreeViewItem GetFolder(string path)
        {
            if (folders.TryGetValue(path, out var existing))
                return existing;
            var slash = path.LastIndexOf('/');
            var node = new TreeViewItem { Header = path[(slash + 1)..], IsExpanded = true };
            folders.Add(path, node);
            if (slash < 0)
                root.Add(node);
            else
                GetFolder(path[..slash]).Items.Add(node);
            return node;
        }
    }

    private void OnRepositoryTreeSelected(object? sender, SelectionChangedEventArgs e) =>
        ShowTreeFile((RepositoryFileTree.SelectedItem as TreeViewItem)?.Tag as RepositoryTreeFile);

    private void ShowTreeFile(RepositoryTreeFile? selection)
    {
        selectedTreeFile = selection?.Key;
        if (selection is null)
        {
            RepositoryTreeDetails.Content = null;
            return;
        }

        var entries = resolvedRepositoryMods.Where(file => file.ProjectId is not null).ToDictionary(file => file.ProjectId!);
        var explicitProjects = repositoryFiles.Select(file => file.ProjectId).OfType<string>().ToHashSet();
        var pin = selection.Automatic && selection.File.ProjectId is { } project && entries.TryGetValue(project, out var dependency)
            ? CreateDependencyPin(selection.File, dependency.ModVersionId) : null;
        RepositoryTreeDetails.Content = CreateRepositoryFileCard(selection.File, selection.Automatic,
            selection.Automatic ? null : FindAutomaticDependencies(selection.File.ProjectId, entries, explicitProjects), pin);
    }
}
