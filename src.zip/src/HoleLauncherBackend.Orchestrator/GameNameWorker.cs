using HoleLauncherBackend.Shared;
using Npgsql;

namespace HoleLauncherBackend.Orchestrator;

internal sealed class GameNameWorker(GameNameOperations operations, DraslClient drasl,
    ILogger<GameNameWorker> logger) : BackgroundService
{
    private static readonly TimeSpan PollInterval = TimeSpan.FromSeconds(1);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!drasl.IsConfigured)
            return;

        using var timer = new PeriodicTimer(PollInterval);
        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            try
            {
                await operations.ReportAsync(stoppingToken);
                if (await operations.ProcessNextAsync(stoppingToken))
                    await operations.ReportAsync(stoppingToken);
            }
            catch (NpgsqlException error)
            {
                logger.LogWarning("Could not process game name history: {ErrorType}", error.GetType().Name);
            }
        }
    }
}
